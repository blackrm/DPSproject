function myInfo(lastname, zip, letterid) {

	// This prints out the last name, zip, and letter id entered by the site visitor
	document.write("<h1>Tickets Found</h1>");
	document.write("Your last name is " + lastname);
	document.write("<br>");
	document.write("Your zip code is " + zip);
	document.write("<br>");
	document.write("Your letter id is " + letterid);
	document.write("<br>");
}

